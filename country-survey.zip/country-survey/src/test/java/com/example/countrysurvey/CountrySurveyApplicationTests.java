package com.example.countrysurvey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountrySurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
